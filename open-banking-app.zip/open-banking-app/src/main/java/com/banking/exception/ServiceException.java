package com.banking.exception;

public class ServiceException extends RuntimeException {
}
