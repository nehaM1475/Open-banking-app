package com.banking.exception;

public class DataAccessException extends RuntimeException {
}
