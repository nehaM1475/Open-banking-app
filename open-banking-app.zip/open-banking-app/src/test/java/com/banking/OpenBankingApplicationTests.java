package com.banking;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.tomcat.jni.User;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.banking.controller.ATMController;
import com.banking.model.ATM;
import com.banking.model.ATMResponse;
import com.banking.repository.ATMRepository;
import com.banking.service.ATMFinderService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.core.util.ContentTypeUtil;
import junit.framework.Assert;


@RunWith(SpringRunner.class)
@WebMvcTest(ATMController.class)
@AutoConfigureMockMvc
class OpenBankingApplicationTests {
	
	@MockBean
	private ATMFinderService atmFinderService;
	
	@Autowired
    private WebApplicationContext wac;
	
	@Autowired
	private ATMController atmController;

	@Autowired
	private MockMvc mockMvc;
	
	
	@Before
    public void setup () {
        DefaultMockMvcBuilder builder = MockMvcBuilders.webAppContextSetup(this.wac);
        this.mockMvc = builder.build();   }
    
	
	@Test 
	void smokeTest() {
		Assert.assertNotNull(atmController); }
	
	
	@Test
	void verifyResponseStatusIsOk() throws Exception {
        List<ATM> myList=new ArrayList<ATM>();
		List<String> currency= new ArrayList<String>();
		currency.add("GBP");
		ATM atm=new ATM();
		atm.setIdentification("Sk13TN");
		atm.setSupportedCurrencies(currency);
		myList.add(atm);
		when(atmFinderService.getATMByIdentification(anyString())).thenReturn(myList);
		ResultMatcher ok = MockMvcResultMatchers.status().isOk();
        MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.get("/atms?identification=Sk13TN");
        this.mockMvc.perform(builder)
        .andExpect(ok); }
	
    @Test
    void verifyResponseStatusIsSuccess() throws Exception {
        List<ATM> myList=new ArrayList<ATM>();
	    List<String> currency= new ArrayList<String>();
	    currency.add("INR");
	    ATM atm=new ATM();
	    atm.setIdentification("SO151GE");
	    atm.setSupportedCurrencies(currency);
	    myList.add(atm);
	    when( atmFinderService.getATMByIdentification(anyString())).thenReturn(myList);
	    ResultMatcher ok = MockMvcResultMatchers.status().is(200);
        MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.get("/atms?identification=SO151GE");
        this.mockMvc.perform(builder).andExpect(ok); }

      @Test
     void verifyContentInResponse() throws Exception {
        List<ATM> myList=new ArrayList<ATM>();
	    List<String> currency= new ArrayList<String>();
	    currency.add("GBP");
	    ATM atm=new ATM();
	    atm.setIdentification("M220RR");
	    atm.setSupportedCurrencies(currency);
	    myList.add(atm);
        Mockito.when(atmFinderService.getATMByIdentification(Mockito.anyString())).thenReturn(myList);
        RequestBuilder builder = MockMvcRequestBuilders.get(
	    "/atms?identification=M220RR").accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(builder).andReturn();
        System.out.println("Result is"+result);
        String expectedJson=this.mapToJson(myList);
        System.out.println("ExpectedJson is"+expectedJson);
        String outputinjson=result.getResponse().getContentAsString();
        System.out.println("OutputJson is"+outputinjson);
        Assert.assertEquals(outputinjson,expectedJson); }

     private String mapToJson (Object object) throws JsonProcessingException{
        ObjectMapper objectMapper= new ObjectMapper () ;
        return objectMapper.writeValueAsString(object); }












}
